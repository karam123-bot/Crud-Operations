-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: Jul 23, 2023 at 09:14 AM
-- Server version: 10.6.5-MariaDB
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crud`
--

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `address`, `phone`, `date`) VALUES
(13, 'Fran Wilson ', 'franwilson@mail.com', 'C/ Araquil, 67, Madrid, Spain', '(204) 619-5731', '2023-07-23 09:06:11'),
(12, 'Maria Anders', 'mariaanders@mail.com', '25, rue Lauriston, Paris, France', '(503) 555-9931', '2023-07-23 07:33:03'),
(11, 'Dominique Perrier', 'dominiqueperrier@mail.com', 'Obere Str. 57, Berlin, Germany', '(313) 555-5735', '2023-07-23 07:32:27'),
(10, 'Thomas Hardy', 'thomashardy@mail.com', '89 Chiaroscuro Rd, Portland, USA', '(171) 555-2222', '2023-07-23 07:31:34'),
(14, 'Martin Blank', 'martinblank@mail.com', 'martinblank@mail.com', '(480) 631-2097', '2023-07-23 07:34:09');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
