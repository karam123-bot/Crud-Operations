<?php
include("config.php");

if(isset($_GET['id'])){

    $id=$_GET['id'];
}
$delete="delete from user where id='$id'";
$q=mysqli_query($conn,$delete);
if($q==true){

echo "<script>window.alert('Data Deleted Successfully....','_self')</script>";
echo "<script>window.open('index','_self')</script>";
}else{

echo "<script>window.alert('Something Went Wrong','_self')</script>";
echo "<script>window.open('index','_self')</script>";

}

?>